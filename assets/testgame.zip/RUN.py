
downloaded = False
import AutoUpdate
import urllib.request

AutoUpdate.set_url("https://raw.githubusercontent.com/jonathaus/runTEST/main/version.txt?token=GHSAT0AAAAAACCLA7YHIJSWWUQM4B4VUGF2ZFKDKYA")
AutoUpdate.set_current_version("1.0")

print(AutoUpdate.is_up_to_date())  

if not AutoUpdate.is_up_to_date():
    urllib.request.urlretrieve("https://jonagames.com/assets/testgame.zip", "testgame.zip")
    downloaded = True
    

from zipfile import ZipFile
import os

if downloaded:
    extracted = False
    with ZipFile('testgame.zip', 'r') as zip:
        zip.extractall()
        extracted = True

    

    if extracted:
        os.system("main.pyw")
